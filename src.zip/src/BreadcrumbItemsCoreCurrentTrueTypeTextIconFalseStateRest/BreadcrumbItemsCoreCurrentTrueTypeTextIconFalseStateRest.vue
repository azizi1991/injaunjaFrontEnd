<script setup>
import { defineProps } from "vue";
defineProps({
  current: {
    type: String,
    default: "false",
  },
  type: {
    type: String,
    default: "text",
  },
  icon: {
    type: String,
    default: "false",
  },
  state: {
    type: String,
    default: "focused",
  },
});
</script>

<template>
  <div
    :class="
      'breadcrumb-items-core-current-true-type-text-icon-false-state-rest ' +
      'current-' +
      current +
      ' type-' +
      type +
      ' icon-' +
      icon +
      ' state-' +
      state
    "
  >
    <div class="text">Projects</div>
  </div>
</template>

<style scoped>
.breadcrumb-items-core-current-true-type-text-icon-false-state-rest,
.breadcrumb-items-core-current-true-type-text-icon-false-state-rest * {
  box-sizing: border-box;
}
.breadcrumb-items-core-current-true-type-text-icon-false-state-rest {
  display: flex;
  flex-direction: row;
  gap: 0px;
  align-items: center;
  justify-content: center;
  position: relative;
}
.text {
  color: var(--primary-600, #026e78);
  text-align: left;
  font-family: var(
    --text-14-normal-medium-font-family,
    "Mulish-Regular",
    sans-serif
  );
  font-size: var(--text-14-normal-medium-font-size, 14px);
  line-height: var(--text-14-normal-medium-line-height, 150%);
  font-weight: var(--text-14-normal-medium-font-weight, 400);
  position: relative;
}
</style>
