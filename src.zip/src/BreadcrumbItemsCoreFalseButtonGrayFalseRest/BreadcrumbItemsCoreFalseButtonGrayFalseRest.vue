<script setup>
import { defineProps } from "vue";
defineProps({});
</script>

<template>
  <div class="breadcrumb-items-core-false-button-gray-false-rest">
    <div class="text">Projects</div>
  </div>
</template>

<style scoped>
.breadcrumb-items-core-false-button-gray-false-rest,
.breadcrumb-items-core-false-button-gray-false-rest * {
  box-sizing: border-box;
}
.breadcrumb-items-core-false-button-gray-false-rest {
  border-radius: 6px;
  padding: 4px 8px 4px 8px;
  display: flex;
  flex-direction: row;
  gap: 0px;
  align-items: center;
  justify-content: center;
  height: 32px;
  position: relative;
}
.text {
  color: var(--lgray-500, #667085);
  text-align: left;
  font-family: var(
    --text-14-normal-medium-font-family,
    "Mulish-Regular",
    sans-serif
  );
  font-size: var(--text-14-normal-medium-font-size, 14px);
  line-height: var(--text-14-normal-medium-line-height, 150%);
  font-weight: var(--text-14-normal-medium-font-weight, 400);
  position: relative;
}
</style>
