<script setup>
import { defineProps } from "vue";
import BreadcrumbItemsCoreCurrentFalseTypeTextIconTrueStateHover from "../BreadcrumbItemsCoreCurrentFalseTypeTextIconTrueStateHover/BreadcrumbItemsCoreCurrentFalseTypeTextIconTrueStateHover.vue";
import BreadcrumbItemsCoreCurrentFalseTypeTextIconFalseStateHover from "../BreadcrumbItemsCoreCurrentFalseTypeTextIconFalseStateHover/BreadcrumbItemsCoreCurrentFalseTypeTextIconFalseStateHover.vue";

defineProps({
  current: {
    type: String,
    default: "false",
  },
  type: {
    type: String,
    default: "text",
  },
  icon: {
    type: String,
    default: "false",
  },
  state: {
    type: String,
    default: "focused",
  },
});
</script>

<template>
  <div
    :class="
      'breadcrumb-items-core-current-false-type-icon-text-icon-true-state-hover ' +
      'current-' +
      current +
      ' type-' +
      type +
      ' icon-' +
      icon +
      ' state-' +
      state
    "
  >
    <BreadcrumbItemsCoreCurrentFalseTypeTextIconTrueStateHover
      icon="true"
      state="hover"
      class="breadcrumb-items-core-instance"
    ></BreadcrumbItemsCoreCurrentFalseTypeTextIconTrueStateHover>
    <BreadcrumbItemsCoreCurrentFalseTypeTextIconFalseStateHover
      state="hover"
      class="breadcrumb-items-core-instance"
    ></BreadcrumbItemsCoreCurrentFalseTypeTextIconFalseStateHover>
  </div>
</template>

<style scoped>
.breadcrumb-items-core-current-false-type-icon-text-icon-true-state-hover,
.breadcrumb-items-core-current-false-type-icon-text-icon-true-state-hover * {
  box-sizing: border-box;
}
.breadcrumb-items-core-current-false-type-icon-text-icon-true-state-hover {
  display: flex;
  flex-direction: row;
  gap: 8px;
  align-items: center;
  justify-content: center;
  position: relative;
}
.breadcrumb-items-core-instance {
  flex-shrink: 0 !important;
}
</style>
