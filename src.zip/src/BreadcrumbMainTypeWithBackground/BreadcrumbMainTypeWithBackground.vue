<script setup>
import { defineProps } from "vue";
import BreadcrumbItemsCoreFalseButtonGrayTrueRest from "../BreadcrumbItemsCoreFalseButtonGrayTrueRest/BreadcrumbItemsCoreFalseButtonGrayTrueRest.vue";
import ChevronRight from "../ChevronRight/ChevronRight.vue";
import BreadcrumbItemsCoreCurrentFalseTypeIconTextIconTrueStateRest from "../BreadcrumbItemsCoreCurrentFalseTypeIconTextIconTrueStateRest/BreadcrumbItemsCoreCurrentFalseTypeIconTextIconTrueStateRest.vue";
import BreadcrumbItemsCoreFalseButtonGrayFalseRest from "../BreadcrumbItemsCoreFalseButtonGrayFalseRest/BreadcrumbItemsCoreFalseButtonGrayFalseRest.vue";
import BreadcrumbItemsCoreCurrentTrueTypeIconTextIconTrueStateRest from "../BreadcrumbItemsCoreCurrentTrueTypeIconTextIconTrueStateRest/BreadcrumbItemsCoreCurrentTrueTypeIconTextIconTrueStateRest.vue";

defineProps({
  type: {
    type: String,
    default: "with-outline",
  },
});
</script>

<template>
  <div :class="'breadcrumb-main-type-with-background ' + 'type-' + type">
    <div class="tabs">
      <BreadcrumbItemsCoreFalseButtonGrayTrueRest
        class="breadcrumb-items-core-false-button-gray-true-rest-instance"
      ></BreadcrumbItemsCoreFalseButtonGrayTrueRest>
      <ChevronRight class="chevron-right-instance"></ChevronRight>
      <BreadcrumbItemsCoreCurrentFalseTypeIconTextIconTrueStateRest
        type="icon-text"
        icon="true"
        state="rest"
        class="breadcrumb-items-core-instance"
      ></BreadcrumbItemsCoreCurrentFalseTypeIconTextIconTrueStateRest>
      <ChevronRight class="chevron-right-instance2"></ChevronRight>
      <BreadcrumbItemsCoreCurrentFalseTypeIconTextIconTrueStateRest
        type="icon-text"
        icon="true"
        state="rest"
        class="breadcrumb-items-core-instance"
      ></BreadcrumbItemsCoreCurrentFalseTypeIconTextIconTrueStateRest>
      <ChevronRight class="chevron-right-instance3"></ChevronRight>
      <BreadcrumbItemsCoreFalseButtonGrayFalseRest
        class="breadcrumb-items-core-false-button-gray-false-rest-instance"
      ></BreadcrumbItemsCoreFalseButtonGrayFalseRest>
      <ChevronRight class="chevron-right-instance4"></ChevronRight>
      <BreadcrumbItemsCoreCurrentFalseTypeIconTextIconTrueStateRest
        type="icon-text"
        icon="true"
        state="rest"
        class="breadcrumb-items-core-instance"
      ></BreadcrumbItemsCoreCurrentFalseTypeIconTextIconTrueStateRest>
      <ChevronRight class="chevron-right-instance5"></ChevronRight>
      <slot name="component0">
        <BreadcrumbItemsCoreCurrentFalseTypeIconTextIconTrueStateRest
          type="icon-text"
          icon="true"
          state="rest"
          class="breadcrumb-items-core-instance"
        ></BreadcrumbItemsCoreCurrentFalseTypeIconTextIconTrueStateRest>
      </slot>
      <ChevronRight class="chevron-right-instance6"></ChevronRight>
      <BreadcrumbItemsCoreCurrentTrueTypeIconTextIconTrueStateRest
        current="true"
        type="icon-text"
        icon="true"
        state="rest"
        class="breadcrumb-items-core-instance"
      ></BreadcrumbItemsCoreCurrentTrueTypeIconTextIconTrueStateRest>
    </div>
  </div>
</template>

<style scoped>
.breadcrumb-main-type-with-background,
.breadcrumb-main-type-with-background * {
  box-sizing: border-box;
}
.breadcrumb-main-type-with-background {
  background: var(--primary-50, #eafef1);
  border-radius: 999px;
  padding: 4px;
  display: flex;
  flex-direction: row;
  gap: 0px;
  align-items: center;
  justify-content: center;
  height: 40px;
  position: relative;
}
.tabs {
  padding: 0px 8px 0px 8px;
  display: flex;
  flex-direction: row;
  gap: 8px;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  position: relative;
}
.breadcrumb-items-core-false-button-gray-true-rest-instance {
  flex-shrink: 0 !important;
}
.chevron-right-instance {
  flex-shrink: 0 !important;
  width: 16px !important;
  height: 16px !important;
}
.breadcrumb-items-core-instance {
  flex-shrink: 0 !important;
}
.chevron-right-instance2 {
  flex-shrink: 0 !important;
  width: 16px !important;
  height: 16px !important;
}
.chevron-right-instance3 {
  flex-shrink: 0 !important;
  width: 16px !important;
  height: 16px !important;
}
.breadcrumb-items-core-false-button-gray-false-rest-instance {
  flex-shrink: 0 !important;
}
.chevron-right-instance4 {
  flex-shrink: 0 !important;
  width: 16px !important;
  height: 16px !important;
}
.chevron-right-instance5 {
  flex-shrink: 0 !important;
  width: 16px !important;
  height: 16px !important;
}
.chevron-right-instance6 {
  flex-shrink: 0 !important;
  width: 16px !important;
  height: 16px !important;
}
</style>
