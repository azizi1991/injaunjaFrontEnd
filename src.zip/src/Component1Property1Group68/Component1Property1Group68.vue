<script setup>
import { defineProps } from "vue";
defineProps({
  property1: {
    type: String,
    default: "group-68",
  },
});
</script>

<template>
  <div :class="'component-1-property-1-group-68 ' + 'property-1-' + property1">
    <div class="frame-39">
      <div class="ellipse-26"></div>
      <div class="div">فا</div>
    </div>
  </div>
</template>

<style scoped>
.component-1-property-1-group-68,
.component-1-property-1-group-68 * {
  box-sizing: border-box;
}
.component-1-property-1-group-68 {
  width: 22px;
  height: 22px;
  position: relative;
}
.frame-39 {
  width: 100%;
  height: 100%;
  position: absolute;
  right: 0%;
  left: 0%;
  bottom: 0%;
  top: 0%;
}
.ellipse-26 {
  background: #0a008e;
  border-radius: 50%;
  width: 22px;
  height: 22px;
  position: absolute;
  left: 0px;
  top: 0px;
}
.div {
  color: #ffffff;
  text-align: left;
  font-family: "Raleway-Bold", sans-serif;
  font-size: 11px;
  font-weight: 700;
  position: absolute;
  left: 6px;
  top: 5px;
  width: 10px;
  height: 10px;
}
</style>
