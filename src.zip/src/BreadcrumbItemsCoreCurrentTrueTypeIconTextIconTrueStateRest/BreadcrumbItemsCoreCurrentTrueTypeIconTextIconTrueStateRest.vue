<script setup>
import { defineProps } from "vue";
import BreadcrumbItemsCoreCurrentTrueTypeTextIconTrueStateRest from "../BreadcrumbItemsCoreCurrentTrueTypeTextIconTrueStateRest/BreadcrumbItemsCoreCurrentTrueTypeTextIconTrueStateRest.vue";
import BreadcrumbItemsCoreCurrentTrueTypeTextIconFalseStateRest from "../BreadcrumbItemsCoreCurrentTrueTypeTextIconFalseStateRest/BreadcrumbItemsCoreCurrentTrueTypeTextIconFalseStateRest.vue";

defineProps({
  current: {
    type: String,
    default: "false",
  },
  type: {
    type: String,
    default: "text",
  },
  icon: {
    type: String,
    default: "false",
  },
  state: {
    type: String,
    default: "focused",
  },
});
</script>

<template>
  <div
    :class="
      'breadcrumb-items-core-current-true-type-icon-text-icon-true-state-rest ' +
      'current-' +
      current +
      ' type-' +
      type +
      ' icon-' +
      icon +
      ' state-' +
      state
    "
  >
    <BreadcrumbItemsCoreCurrentTrueTypeTextIconTrueStateRest
      current="true"
      icon="true"
      state="rest"
      class="breadcrumb-items-core-instance"
    ></BreadcrumbItemsCoreCurrentTrueTypeTextIconTrueStateRest>
    <BreadcrumbItemsCoreCurrentTrueTypeTextIconFalseStateRest
      current="true"
      state="rest"
      class="breadcrumb-items-core-instance"
    ></BreadcrumbItemsCoreCurrentTrueTypeTextIconFalseStateRest>
  </div>
</template>

<style scoped>
.breadcrumb-items-core-current-true-type-icon-text-icon-true-state-rest,
.breadcrumb-items-core-current-true-type-icon-text-icon-true-state-rest * {
  box-sizing: border-box;
}
.breadcrumb-items-core-current-true-type-icon-text-icon-true-state-rest {
  display: flex;
  flex-direction: row;
  gap: 8px;
  align-items: center;
  justify-content: center;
  position: relative;
}
.breadcrumb-items-core-instance {
  flex-shrink: 0 !important;
}
</style>
