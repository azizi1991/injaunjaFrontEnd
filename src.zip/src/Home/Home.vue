<script setup>
import { defineProps } from "vue";
defineProps({});
</script>

<template>
  <img class="home" src="home.svg" />
</template>

<style scoped>
.home,
.home * {
  box-sizing: border-box;
}
.home {
  flex-shrink: 0;
  width: 24px;
  height: 24px;
  position: relative;
  overflow: visible;
}
</style>
