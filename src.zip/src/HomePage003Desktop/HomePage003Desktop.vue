<script setup>
import { defineProps } from "vue";
import Component1Property1Group68 from "../Component1Property1Group68/Component1Property1Group68.vue";
import BreadcrumbTypeWithFilledContainerLevelOneContentTextToIconStateHoverPrevious from "../BreadcrumbTypeWithFilledContainerLevelOneContentTextToIconStateHoverPrevious/BreadcrumbTypeWithFilledContainerLevelOneContentTextToIconStateHoverPrevious.vue";
</script>

<template>
  <div class="home-page-003-desktop">
    <div class="frame-833">
      <div class="rectangle-77"></div>
    </div>
    <img class="untitled-design-5-11" src="untitled-design-5-110.png" />
    <div class="frame-932">
      <img class="untitled-design-2-18" src="untitled-design-2-180.png" />
      <img class="untitled-design-2-19" src="untitled-design-2-190.png" />
      <img class="untitled-design-2-20" src="untitled-design-2-200.png" />
      <img class="untitled-design-2-22" src="untitled-design-2-220.png" />
      <img class="untitled-design-23" src="untitled-design-230.png" />
      <Component1Property1Group68
        class="component-1-instance"
      ></Component1Property1Group68>
      <div class="rectangle-213"></div>
      <div class="line-56"></div>
      <div class="line-55"></div>
      <div class="line-57"></div>
      <div class="line-58"></div>
      <div class="line-60"></div>
      <div class="apartment">
        <div class="frame-929"></div>
      </div>
      <div class="apartment2">
        <img class="untitled-design-20-23" src="untitled-design-20-230.png" />
      </div>
      <div class="apartment3"></div>
      <img class="untitled-design-20-24" src="untitled-design-20-240.png" />
      <img class="untitled-design-20-25" src="untitled-design-20-250.png" />
      <div class="line-2"></div>
      <div class="frame-856">
        <div class="frame-851">
          <div class="ellipse-6"></div>
          <div class="ellipse-7"></div>
          <div class="ellipse-8"></div>
        </div>
        <div class="frame-855">
          <div class="rectangle-31"></div>
          <div class="see-more">See more</div>
          <div
            class="banner-advertisement-and-announcement-of-our-own-company-a-banner-for-application-notes"
          >
            <span>
              <span
                class="banner-advertisement-and-announcement-of-our-own-company-a-banner-for-application-notes-span"
              >
                Banner advertisement and announcement of our own company
                <br />
              </span>
              <span
                class="banner-advertisement-and-announcement-of-our-own-company-a-banner-for-application-notes-span2"
              >
                <br />
              </span>
              <span
                class="banner-advertisement-and-announcement-of-our-own-company-a-banner-for-application-notes-span3"
              >
                A banner for Application notes...
              </span>
            </span>
          </div>
        </div>
        <img class="untitled-design-18-6" src="untitled-design-18-60.png" />
        <div class="frame-854">
          <div class="rectangle-312"></div>
          <div class="see-more2">See more</div>
        </div>
        <div
          class="banner-advertisement-and-announcement-of-our-own-company-a-banner-for-application-notes2"
        >
          <span>
            <span
              class="banner-advertisement-and-announcement-of-our-own-company-a-banner-for-application-notes-2-span"
            >
              Banner advertisement and announcement of our own company
              <br />
            </span>
            <span
              class="banner-advertisement-and-announcement-of-our-own-company-a-banner-for-application-notes-2-span2"
            >
              <br />
            </span>
            <span
              class="banner-advertisement-and-announcement-of-our-own-company-a-banner-for-application-notes-2-span3"
            >
              A banner for Application notes....
            </span>
          </span>
        </div>
        <div class="noto-v-1-fishing-pole">
          <img class="vector" src="vector0.svg" />
          <img class="vector2" src="vector1.svg" />
          <img class="vector3" src="vector2.svg" />
          <img class="vector4" src="vector3.svg" />
          <img class="vector5" src="vector4.svg" />
          <img class="vector6" src="vector5.svg" />
          <img class="vector7" src="vector6.svg" />
          <img class="vector8" src="vector7.svg" />
          <img class="group" src="group0.svg" />
          <img class="vector9" src="vector8.svg" />
          <img class="vector10" src="vector9.svg" />
          <img class="vector11" src="vector10.svg" />
        </div>
        <div class="frame-848">
          <div class="ellipse-62"></div>
          <div class="ellipse-72"></div>
          <div class="ellipse-82"></div>
        </div>
        <div class="frame-852">
          <div class="rectangle-313"></div>
          <div class="see-more3">See more</div>
          <div
            class="banner-advertisement-and-announcement-of-our-own-company-a-banner-for-application-notes3"
          >
            <span>
              <span
                class="banner-advertisement-and-announcement-of-our-own-company-a-banner-for-application-notes-3-span"
              >
                Banner advertisement and announcement of our own company
                <br />
              </span>
              <span
                class="banner-advertisement-and-announcement-of-our-own-company-a-banner-for-application-notes-3-span2"
              >
                <br />
              </span>
              <span
                class="banner-advertisement-and-announcement-of-our-own-company-a-banner-for-application-notes-3-span3"
              >
                A banner for Application notes...
              </span>
            </span>
          </div>
          <img class="untitled-design-19-2" src="untitled-design-19-20.png" />
        </div>
      </div>
      <img class="untitled-design-6-1" src="untitled-design-6-10.png" />
      <div class="anywhere">Anywhere</div>
      <img class="untitled-design-6-2" src="untitled-design-6-20.png" />
      <div class="anyweek">Anyweek</div>
      <img class="untitled-design-6-4" src="untitled-design-6-40.png" />
      <div class="guests">Guests</div>
      <div class="frame-941">
        <img class="untitled-design-2-21" src="untitled-design-2-210.png" />
        <div class="ellipse-35"></div>
      </div>
      <div class="frame-940">
        <img class="inja-unja-2-2" src="inja-unja-2-20.png" />
      </div>
      <div class="frame-955">
        <div class="ellipse-80"></div>
        <img class="untitled-design-2-182" src="untitled-design-2-181.png" />
      </div>
      <BreadcrumbTypeWithFilledContainerLevelOneContentTextToIconStateHoverPrevious
        type="with-filled-container"
        level="one"
        content="text-to-icon"
        state="hover-previous"
        class="breadcrumb-instance"
      ></BreadcrumbTypeWithFilledContainerLevelOneContentTextToIconStateHoverPrevious>
    </div>
    <div class="frame-968">
      <img class="group-74" src="group-740.svg" />
    </div>
  </div>
</template>

<style scoped>
.home-page-003-desktop,
.home-page-003-desktop * {
  box-sizing: border-box;
}
.home-page-003-desktop {
  background: #fafafa;
  border-radius: 17.14px;
  height: 1024px;
  position: relative;
  overflow: hidden;
}
.frame-833 {
  width: 1440px;
  height: 85px;
  position: absolute;
  left: 0px;
  top: 937px;
  overflow: hidden;
}
.rectangle-77 {
  background: #f7f7f7;
  border-radius: 0px 0px 24px 24px;
  width: 1440px;
  height: 83px;
  position: absolute;
  left: 0px;
  top: 2px;
}
.untitled-design-5-11 {
  width: 667px;
  height: 570px;
  position: absolute;
  left: 778px;
  top: 243px;
  object-fit: cover;
}
.frame-932 {
  width: 1445px;
  height: 1024px;
  position: sticky;
  left: 0px;
  top: 0px;
  overflow: hidden;
}
.untitled-design-2-18 {
  width: 68px;
  height: 64px;
  position: absolute;
  left: 862px;
  top: 944px;
  object-fit: cover;
}
.untitled-design-2-19 {
  width: 70px;
  height: 66px;
  position: absolute;
  left: 509px;
  top: 946px;
  object-fit: cover;
}
.untitled-design-2-20 {
  width: 68px;
  height: 68px;
  position: absolute;
  left: 690px;
  top: 944px;
  object-fit: cover;
}
.untitled-design-2-22 {
  width: 64px;
  height: 60px;
  position: absolute;
  left: 323px;
  top: 95px;
  object-fit: cover;
}
.untitled-design-23 {
  width: 83px;
  height: 85px;
  position: absolute;
  left: 1029px;
  top: 939px;
  object-fit: cover;
}
.component-1-instance {
  width: 33.26px !important;
  height: 34.76px !important;
  position: absolute !important;
  left: 1311.11px !important;
  top: 48.89px !important;
  transform-origin: 0 0 !important;
  transform: rotate(0.61deg) scale(1, 1) !important;
}
.rectangle-213 {
  border-radius: 100px;
  border-style: solid;
  border-color: #979797;
  border-width: 2px;
  width: 836px;
  height: 88px;
  position: absolute;
  left: 302px;
  top: 84px;
}
.line-56 {
  margin-top: -2px;
  border-style: solid;
  border-color: #979797;
  border-width: 2px 0 0 0;
  width: 57px;
  height: 0px;
  position: absolute;
  left: 897px;
  top: 153px;
  transform-origin: 0 0;
  transform: rotate(-90deg) scale(1, 1);
}
.line-55 {
  margin-top: -2px;
  border-style: solid;
  border-color: #979797;
  border-width: 2px 0 0 0;
  width: 57px;
  height: 0px;
  position: absolute;
  left: 692px;
  top: 153px;
  transform-origin: 0 0;
  transform: rotate(-90deg) scale(1, 1);
}
.line-57 {
  margin-top: -1px;
  border-style: solid;
  border-color: #979797;
  border-width: 1px 0 0 0;
  width: 77.01px;
  height: 0px;
  position: absolute;
  left: 559px;
  top: 153px;
  transform-origin: 0 0;
  transform: rotate(0.744deg) scale(1, 1);
}
.line-58 {
  margin-top: -1px;
  border-style: solid;
  border-color: #979797;
  border-width: 1px 0 0 0;
  width: 75px;
  height: 0px;
  position: absolute;
  left: 773px;
  top: 153px;
}
.line-60 {
  margin-top: -1px;
  border-style: solid;
  border-color: #979797;
  border-width: 1px 0 0 0;
  width: 55px;
  height: 0px;
  position: absolute;
  left: 1005px;
  top: 154px;
}
.apartment {
  background: #f7f7f7;
  border-radius: 8.56px;
  border-style: solid;
  border-color: #e2e2e2;
  border-width: 1px;
  padding: 8.56px 13.7px 8.56px 13.7px;
  display: flex;
  flex-direction: row;
  gap: 8.56px;
  align-items: center;
  justify-content: center;
  width: 125px;
  height: 120px;
  position: absolute;
  left: 178px;
  top: 296px;
  box-shadow: 0px 4px 4px 0px rgba(0, 0, 0, 0.25);
  overflow: hidden;
}
.frame-929 {
  flex-shrink: 0;
  width: 71px;
  height: 71px;
  position: relative;
  overflow: hidden;
}
.apartment2 {
  background: #f7f7f7;
  border-radius: 8.56px;
  border-style: solid;
  border-color: #e2e2e2;
  border-width: 1px;
  padding: 8.56px 13.7px 8.56px 13.7px;
  display: flex;
  flex-direction: row;
  gap: 8.56px;
  align-items: center;
  justify-content: center;
  width: 124px;
  height: 120px;
  position: absolute;
  left: 361px;
  top: 293px;
  box-shadow: 0px 4px 4px 0px rgba(0, 0, 0, 0.25);
  overflow: hidden;
}
.untitled-design-20-23 {
  flex-shrink: 0;
  width: 138px;
  height: 131px;
  position: relative;
  object-fit: cover;
}
.apartment3 {
  background: #f7f7f7;
  border-radius: 8.56px;
  border-style: solid;
  border-color: #e2e2e2;
  border-width: 1px;
  padding: 8.56px 13.7px 8.56px 13.7px;
  display: flex;
  flex-direction: row;
  gap: 8.56px;
  align-items: center;
  justify-content: center;
  width: 125px;
  height: 120px;
  position: absolute;
  left: 550px;
  top: 296px;
  box-shadow: 0px 4px 4px 0px rgba(0, 0, 0, 0.25);
  overflow: hidden;
}
.untitled-design-20-24 {
  width: 119px;
  height: 114px;
  position: absolute;
  left: 558px;
  top: 300px;
  object-fit: cover;
}
.untitled-design-20-25 {
  width: 113px;
  height: 107px;
  position: absolute;
  left: 190px;
  top: 303px;
  object-fit: cover;
}
.line-2 {
  margin-top: -1px;
  border-style: solid;
  border-color: rgba(0, 0, 0, 0.5);
  border-width: 1px 0 0 0;
  width: 541px;
  height: 0px;
  position: absolute;
  left: 152px;
  top: 440px;
}
.frame-856 {
  width: 566px;
  height: 255px;
  position: absolute;
  left: 133px;
  top: 470px;
  overflow-x: auto;
}
.frame-851 {
  width: 58px;
  height: 20px;
  position: absolute;
  left: 1177px;
  top: 172px;
  overflow: hidden;
}
.ellipse-6 {
  background: #d9d9d9;
  border-radius: 50%;
  width: 8px;
  height: 8px;
  position: absolute;
  left: 6px;
  top: 5px;
}
.ellipse-7 {
  background: #d9d9d9;
  border-radius: 50%;
  border-style: solid;
  border-color: transparent;
  border-width: 1px;
  width: 8px;
  height: 8px;
  position: absolute;
  left: 22px;
  top: 5px;
}
.ellipse-8 {
  background: #1b86ea;
  border-radius: 50%;
  border-style: solid;
  border-color: transparent;
  border-width: 1px;
  width: 8px;
  height: 8px;
  position: absolute;
  left: 37px;
  top: 5px;
}
.frame-855 {
  background: #4caf50;
  border-radius: 17px;
  width: 620px;
  height: 169px;
  position: absolute;
  left: 620px;
  top: 3px;
  box-shadow: 0px 4px 4px 0px rgba(0, 0, 0, 0.25);
  overflow: hidden;
}
.rectangle-31 {
  background: #0a008e;
  border-radius: 17px;
  width: 67px;
  height: 24px;
  position: absolute;
  left: 14px;
  top: 134px;
}
.see-more {
  color: #ffffff;
  text-align: left;
  font-family: "Raleway-Bold", sans-serif;
  font-size: 10.272025108337402px;
  font-weight: 700;
  position: absolute;
  left: 25px;
  top: 139px;
  width: 96px;
  height: 15px;
}
.banner-advertisement-and-announcement-of-our-own-company-a-banner-for-application-notes {
  color: #000000;
  text-align: left;
  position: absolute;
  left: 14px;
  top: 9px;
  width: 382px;
  height: 123px;
}
.banner-advertisement-and-announcement-of-our-own-company-a-banner-for-application-notes-span {
  color: #000000;
  font-family: "Raleway-Bold", sans-serif;
  font-size: 20px;
  font-weight: 700;
}
.banner-advertisement-and-announcement-of-our-own-company-a-banner-for-application-notes-span2 {
  color: #000000;
  font-family: "Raleway-Bold", sans-serif;
  font-size: 10.272025108337402px;
  font-weight: 700;
}
.banner-advertisement-and-announcement-of-our-own-company-a-banner-for-application-notes-span3 {
  color: #000000;
  font-family: "Raleway-Regular", sans-serif;
  font-size: 16px;
  font-weight: 400;
}
.untitled-design-18-6 {
  width: 184px;
  height: 136px;
  position: absolute;
  left: 1023px;
  top: 12px;
  object-fit: cover;
}
.frame-854 {
  background: #373f46;
  border-radius: 17px;
  width: 552px;
  height: 158px;
  position: absolute;
  left: 14px;
  top: 3px;
  box-shadow: 0px 4px 4px 0px rgba(0, 0, 0, 0.25);
  overflow: hidden;
}
.rectangle-312 {
  background: #0a008e;
  border-radius: 17px;
  width: 69px;
  height: 24px;
  position: absolute;
  left: 30px;
  top: 131px;
}
.see-more2 {
  color: #ffffff;
  text-align: left;
  font-family: "Raleway-Bold", sans-serif;
  font-size: 10.272025108337402px;
  font-weight: 700;
  position: absolute;
  left: 41px;
  top: 136px;
  width: 96px;
  height: 15px;
}
.banner-advertisement-and-announcement-of-our-own-company-a-banner-for-application-notes2 {
  color: #ffffff;
  text-align: left;
  position: absolute;
  left: 25px;
  top: 12px;
  width: 354px;
  height: 140px;
}
.banner-advertisement-and-announcement-of-our-own-company-a-banner-for-application-notes-2-span {
  color: #ffffff;
  font-family: "Raleway-Bold", sans-serif;
  font-size: 20px;
  font-weight: 700;
}
.banner-advertisement-and-announcement-of-our-own-company-a-banner-for-application-notes-2-span2 {
  color: #ffffff;
  font-family: "Raleway-Bold", sans-serif;
  font-size: 10.272025108337402px;
  font-weight: 700;
}
.banner-advertisement-and-announcement-of-our-own-company-a-banner-for-application-notes-2-span3 {
  color: #ffffff;
  font-family: "Raleway-Regular", sans-serif;
  font-size: 16px;
  font-weight: 400;
}
.noto-v-1-fishing-pole {
  width: 126px;
  height: 133px;
  position: absolute;
  left: 415px;
  top: 19px;
  box-shadow: 0px 4px 4px 0px rgba(0, 0, 0, 0.25);
  overflow: hidden;
}
.vector {
  width: 23.02%;
  height: 41.62%;
  position: absolute;
  right: 42.61%;
  left: 34.38%;
  bottom: 48.05%;
  top: 10.33%;
  overflow: visible;
}
.vector2 {
  width: 42.73%;
  height: 97.16%;
  position: absolute;
  right: 3.01%;
  left: 54.26%;
  bottom: 2.69%;
  top: 0.15%;
  overflow: visible;
}
.vector3 {
  width: 21.98%;
  height: 41.7%;
  position: absolute;
  right: 10.72%;
  left: 67.3%;
  bottom: 0.98%;
  top: 57.32%;
  overflow: visible;
}
.vector4 {
  width: 9.25%;
  height: 16.64%;
  position: absolute;
  right: 17.95%;
  left: 72.8%;
  bottom: 18.46%;
  top: 64.9%;
  overflow: visible;
}
.vector5 {
  width: 9.08%;
  height: 6.86%;
  position: absolute;
  right: 44.43%;
  left: 46.49%;
  bottom: 17.91%;
  top: 75.23%;
  overflow: visible;
}
.vector6 {
  width: 13%;
  height: 11.28%;
  position: absolute;
  right: 35.06%;
  left: 51.94%;
  bottom: 17.92%;
  top: 70.8%;
  overflow: visible;
}
.vector7 {
  width: 12.44%;
  height: 9.8%;
  position: absolute;
  right: 22.61%;
  left: 64.95%;
  bottom: 25.98%;
  top: 64.22%;
  overflow: visible;
}
.vector8 {
  width: 16.04%;
  height: 14.51%;
  position: absolute;
  right: 22.89%;
  left: 61.07%;
  bottom: 19.53%;
  top: 65.96%;
  overflow: visible;
}
.group {
  width: 14.84%;
  height: 18.71%;
  position: absolute;
  right: 25.47%;
  left: 59.68%;
  bottom: 10.11%;
  top: 71.18%;
  overflow: visible;
}
.vector9 {
  width: 6.01%;
  height: 10.49%;
  position: absolute;
  right: 16.77%;
  left: 77.22%;
  bottom: 25.5%;
  top: 64.01%;
  overflow: visible;
}
.vector10 {
  width: 46.38%;
  height: 22.85%;
  position: absolute;
  right: 39.17%;
  left: 14.45%;
  bottom: 49.15%;
  top: 28%;
  overflow: visible;
}
.vector11 {
  width: 38.92%;
  height: 51.28%;
  position: absolute;
  right: 58.08%;
  left: 3%;
  bottom: 0.14%;
  top: 48.58%;
  overflow: visible;
}
.frame-848 {
  width: 51px;
  height: 20px;
  position: absolute;
  left: 264px;
  top: 177px;
  overflow: hidden;
}
.ellipse-62 {
  background: #1b86ea;
  border-radius: 50%;
  width: 10px;
  height: 10px;
  position: absolute;
  left: 1px;
  top: 5px;
}
.ellipse-72 {
  background: #d9d9d9;
  border-radius: 50%;
  border-style: solid;
  border-color: #d9d9d9;
  border-width: 1px;
  width: 10px;
  height: 10px;
  position: absolute;
  left: 21px;
  top: 5px;
}
.ellipse-82 {
  background: #d9d9d9;
  border-radius: 50%;
  border-style: solid;
  border-color: #d9d9d9;
  border-width: 1px;
  width: 10px;
  height: 10px;
  position: absolute;
  left: 40px;
  top: 5px;
}
.frame-852 {
  background: #ffc107;
  border-radius: 17px;
  width: 620px;
  height: 171px;
  position: absolute;
  left: 1240px;
  top: 1px;
  box-shadow: 0px 4px 4px 0px rgba(0, 0, 0, 0.25);
  overflow: hidden;
}
.rectangle-313 {
  background: #0a008e;
  border-radius: 17px;
  width: 68px;
  height: 24px;
  position: absolute;
  left: 14px;
  top: 100px;
}
.see-more3 {
  color: #ffffff;
  text-align: left;
  font-family: "Raleway-Bold", sans-serif;
  font-size: 10.272025108337402px;
  font-weight: 700;
  position: absolute;
  left: 25px;
  top: 105px;
  width: 96px;
  height: 15px;
}
.banner-advertisement-and-announcement-of-our-own-company-a-banner-for-application-notes3 {
  color: #000000;
  text-align: left;
  position: absolute;
  left: 17px;
  top: 13px;
  width: 351px;
}
.banner-advertisement-and-announcement-of-our-own-company-a-banner-for-application-notes-3-span {
  color: #000000;
  font-family: "Raleway-Bold", sans-serif;
  font-size: 20px;
  font-weight: 700;
}
.banner-advertisement-and-announcement-of-our-own-company-a-banner-for-application-notes-3-span2 {
  color: #000000;
  font-family: "Raleway-Bold", sans-serif;
  font-size: 10.272025108337402px;
  font-weight: 700;
}
.banner-advertisement-and-announcement-of-our-own-company-a-banner-for-application-notes-3-span3 {
  color: #000000;
  font-family: "Raleway-Regular", sans-serif;
  font-size: 16px;
  font-weight: 400;
}
.untitled-design-19-2 {
  width: 168px;
  height: 96px;
  position: absolute;
  left: 425px;
  top: 37px;
  object-fit: cover;
}
.group-93 {
  position: absolute;
  inset: 0;
}
.untitled-design-6-1 {
  width: 135px;
  height: 81px;
  position: absolute;
  left: 425px;
  top: 84px;
  object-fit: cover;
}
.anywhere {
  color: #979797;
  text-align: left;
  font-family: "Raleway-Bold", sans-serif;
  font-size: 16px;
  font-weight: 700;
  position: absolute;
  left: 560px;
  top: 132px;
  width: 82px;
  height: 22px;
}
.group-92 {
  position: absolute;
  inset: 0;
}
.untitled-design-6-2 {
  width: 68px;
  height: 55px;
  position: absolute;
  left: 705px;
  top: 99px;
  object-fit: cover;
}
.anyweek {
  color: #979797;
  text-align: left;
  font-family: "Raleway-Bold", sans-serif;
  font-size: 16px;
  font-weight: 700;
  position: absolute;
  left: 775px;
  top: 132px;
  width: 82px;
  height: 22px;
}
.group-94 {
  position: absolute;
  inset: 0;
}
.untitled-design-6-4 {
  width: 66px;
  height: 53px;
  position: absolute;
  left: 925px;
  top: 102px;
  object-fit: cover;
}
.guests {
  color: #979797;
  text-align: left;
  font-family: "Raleway-Bold", sans-serif;
  font-size: 16px;
  font-weight: 700;
  position: absolute;
  left: 1007px;
  top: 130px;
  width: 82px;
  height: 22px;
}
.frame-941 {
  width: 80px;
  height: 81px;
  position: absolute;
  left: 318px;
  top: 946px;
  overflow: hidden;
}
.untitled-design-2-21 {
  width: 80px;
  height: 81px;
  position: absolute;
  left: 0px;
  top: 0px;
  object-fit: cover;
}
.ellipse-35 {
  background: #0a008e;
  border-radius: 50%;
  width: 19px;
  height: 19px;
  position: absolute;
  left: 51px;
  top: 21px;
}
.frame-940 {
  width: 117px;
  height: 151px;
  position: absolute;
  left: 42px;
  top: 46px;
  overflow: hidden;
}
.inja-unja-2-2 {
  width: 152px;
  height: 138px;
  position: absolute;
  left: -15px;
  top: 0px;
  object-fit: cover;
}
.frame-955 {
  width: 89px;
  height: 104px;
  position: absolute;
  left: 48px;
  top: 319px;
  overflow: hidden;
}
.ellipse-80 {
  background: rgba(217, 217, 217, 0.5);
  border-radius: 50%;
  border-style: solid;
  border-color: #0a008e;
  border-width: 1px;
  width: 72px;
  height: 70px;
  position: absolute;
  left: 1px;
  top: 0px;
}
.untitled-design-2-182 {
  width: 75px;
  height: 69px;
  position: absolute;
  left: -2px;
  top: 1px;
  object-fit: cover;
}
.breadcrumb-instance {
  position: absolute !important;
  left: 1200px !important;
  top: 40px !important;
}
.frame-968 {
  width: 66px;
  height: 39px;
  position: sticky;
  left: 1350px;
  top: 47px;
  overflow: hidden;
}
.group-74 {
  height: auto;
  position: absolute;
  left: 5px;
  top: 5px;
  overflow: visible;
}
</style>
