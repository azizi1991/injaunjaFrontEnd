<script setup>
import { defineProps } from "vue";
import BreadcrumbItemsCoreCurrentFalseTypeIconTextIconTrueStateHover from "../BreadcrumbItemsCoreCurrentFalseTypeIconTextIconTrueStateHover/BreadcrumbItemsCoreCurrentFalseTypeIconTextIconTrueStateHover.vue";
import BreadcrumbItemsCoreCurrentFalseTypeIconTextIconTrueStateRest from "../BreadcrumbItemsCoreCurrentFalseTypeIconTextIconTrueStateRest/BreadcrumbItemsCoreCurrentFalseTypeIconTextIconTrueStateRest.vue";
import BreadcrumbMainTypeWithBackground from "../BreadcrumbMainTypeWithBackground/BreadcrumbMainTypeWithBackground.vue";

defineProps({
  type: {
    type: String,
    default: "without-container",
  },
  level: {
    type: String,
    default: "overflow-middle",
  },
  content: {
    type: String,
    default: "text-to-text",
  },
  state: {
    type: String,
    default: "rest",
  },
});
</script>

<template>
  <div
    :class="
      'breadcrumb-type-with-filled-container-level-one-content-text-to-icon-state-hover-previous ' +
      'type-' +
      type +
      ' level-' +
      level +
      ' content-' +
      content +
      ' state-' +
      state
    "
  >
    <BreadcrumbMainTypeWithBackground
      type="with-background"
      class="breadcrumb-main-instance"
    >
      <template #component0>
        <BreadcrumbItemsCoreCurrentFalseTypeIconTextIconTrueStateHover
          class="breadcrumb-items-core-instance"
          current="false"
          type="icon-text"
          icon="true"
          state="hover"
        ></BreadcrumbItemsCoreCurrentFalseTypeIconTextIconTrueStateHover>
      </template>
    </BreadcrumbMainTypeWithBackground>
  </div>
</template>

<style scoped>
.breadcrumb-type-with-filled-container-level-one-content-text-to-icon-state-hover-previous,
.breadcrumb-type-with-filled-container-level-one-content-text-to-icon-state-hover-previous
  * {
  box-sizing: border-box;
}
.breadcrumb-type-with-filled-container-level-one-content-text-to-icon-state-hover-previous {
  display: flex;
  flex-direction: row;
  gap: 0px;
  align-items: flex-start;
  justify-content: flex-start;
  height: 40px;
  position: relative;
}
.breadcrumb-main-instance {
  flex-shrink: 0 !important;
}

/* nested override styles */
.breadcrumb-items-core-instance {
  flex-shrink: 0 !important;
}
</style>
