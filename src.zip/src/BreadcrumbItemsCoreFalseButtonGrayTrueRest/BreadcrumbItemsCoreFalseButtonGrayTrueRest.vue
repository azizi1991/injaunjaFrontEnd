<script setup>
import { defineProps } from "vue";
import Home from "../Home/Home.vue";

defineProps({});
</script>

<template>
  <div class="breadcrumb-items-core-false-button-gray-true-rest">
    <Home class="home-instance"></Home>
  </div>
</template>

<style scoped>
.breadcrumb-items-core-false-button-gray-true-rest,
.breadcrumb-items-core-false-button-gray-true-rest * {
  box-sizing: border-box;
}
.breadcrumb-items-core-false-button-gray-true-rest {
  border-radius: 6px;
  padding: 4px;
  display: flex;
  flex-direction: row;
  gap: 0px;
  align-items: flex-start;
  justify-content: flex-start;
  position: relative;
}
.home-instance {
  flex-shrink: 0 !important;
}
</style>
