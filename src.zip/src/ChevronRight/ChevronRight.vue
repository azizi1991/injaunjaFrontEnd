<script setup>
import { defineProps } from "vue";
defineProps({});
</script>

<template>
  <img class="chevron-right" src="chevron-right.svg" />
</template>

<style scoped>
.chevron-right,
.chevron-right * {
  box-sizing: border-box;
}
.chevron-right {
  flex-shrink: 0;
  width: 16px;
  height: 16px;
  position: relative;
  overflow: visible;
}
</style>
