<script setup>
import { defineProps } from "vue";
import Home from "../Home/Home.vue";

defineProps({
  current: {
    type: String,
    default: "false",
  },
  type: {
    type: String,
    default: "text",
  },
  icon: {
    type: String,
    default: "false",
  },
  state: {
    type: String,
    default: "focused",
  },
});
</script>

<template>
  <div
    :class="
      'breadcrumb-items-core-current-false-type-text-icon-true-state-hover ' +
      'current-' +
      current +
      ' type-' +
      type +
      ' icon-' +
      icon +
      ' state-' +
      state
    "
  >
    <Home class="home-instance"></Home>
  </div>
</template>

<style scoped>
.breadcrumb-items-core-current-false-type-text-icon-true-state-hover,
.breadcrumb-items-core-current-false-type-text-icon-true-state-hover * {
  box-sizing: border-box;
}
.breadcrumb-items-core-current-false-type-text-icon-true-state-hover {
  display: flex;
  flex-direction: row;
  gap: 0px;
  align-items: flex-start;
  justify-content: flex-start;
  position: relative;
}
.home-instance {
  flex-shrink: 0 !important;
}
</style>
