
<template>
  <HomePage003Desktop  />
</template>

<script>
import HomePage003Desktop from "./HomePage003Desktop/HomePage003Desktop.vue";
import "./vars.css";
import "./styles.css";

export default {
  name: "App",
  components: {
    HomePage003Desktop: HomePage003Desktop,
  },
};
</script>

<style>
</style>

